import random
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split

class labexcercise:
    def lab5questions():
            featureX=[]
            featureY=[]
            targetfeature=[]
            for i in range(0,20):
                featureX.append(random.randrange(1,11)) #random column creation
                featureY.append(random.randrange(1,11))
                  
                #I created two conditions for classification

                if(featureX[i]%2==0 and featureY[i]<5):
                    targetfeature.append(0)
                else:
                    targetfeature.append(1)

            #print(featureX)
            #print(featureY)
            #print(targetfeature)
            colourarray=[]
            for i in targetfeature:
                if(i==0):
                    colourarray.append("blue")
                else:
                    colourarray.append("red") #creating column for colours acc to the class label
            df=pd.DataFrame({'feature X':featureX,'feature Y':featureY,'target column':targetfeature})
            print(df)
            plt.scatter(df['feature X'],df['feature Y'],c=colourarray)
            plt.show()

            featureX=[]
            featureY=[]
            targetfeature=[]
            for i in range(0,10000):
                featureX.append(random.randint(1 * 10, 10 * 10) * 0.1) #creating random test set
                featureY.append(random.randint(1 * 10, 10 * 10) * 0.1)

                if(featureX[i]%2==0 and featureY[i]<5):
                    targetfeature.append(0)
                else:
                    targetfeature.append(1)

                
            testdf=pd.DataFrame({'feature X':featureX,'feature Y':featureY,'target column':targetfeature})
            print(testdf)

            X_train=df.iloc[:,0:2] #since train and test set is different i created seperate variables for both by indexing
            y_train=df.iloc[:,-1]
            

            X_test=testdf.iloc[:,0:2]
            y_test=testdf.iloc[:,-1]
            

    
            from sklearn.neighbors import KNeighborsClassifier #performing knn classification for 3 k 
            neigh=KNeighborsClassifier(n_neighbors=3)
            neigh.fit(X_train, y_train) # fit the model to the training data

            neigh.fit(X_train, y_train) # fit the model to the training data

            print(neigh.score(X_test, y_test))

            predict = neigh.predict(X_test) #predicting class using knn using k=3

            from sklearn.metrics import accuracy_score
            print(accuracy_score(y_test,predict))

            

            colourarraypredicted=[]
            for i in predict:
                if(i==0):
                    colourarraypredicted.append("blue")
                else:
                    colourarraypredicted.append("red")

            plt.scatter(testdf['feature X'],testdf['feature Y'],c=colourarraypredicted) #plotting predicted classlabels
            plt.show()

            for i in range(1,11): #doing same for different k values
                neigh=KNeighborsClassifier(n_neighbors=i)
                neigh.fit(X_train, y_train) # fit the model to the training data

                neigh.fit(X_train, y_train) # fit the model to the training data

                print(neigh.score(X_test, y_test))

                predict = neigh.predict(X_test)

                from sklearn.metrics import accuracy_score
                #print(accuracy_score(y_test,predict))

                

                colourarraypredicted=[]
                for i in predict:
                    if(i==0):
                        colourarraypredicted.append("blue")
                    else:
                        colourarraypredicted.append("red")

                plt.scatter(testdf['feature X'],testdf['feature Y'],c=colourarraypredicted) #plotting for all k values
                plt.show()

    lab5questions()         
                