import pandas as pd
import numpy as np
import statistics
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plotting
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error,mean_absolute_percentage_error,r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression

class A1:
    def irctcstock():
        df=pd.read_excel("E:\\Sharanya\\MLsem4\\Lab_Session1_Data.xlsx", 'IRCTC Stock Price')
        DataArray=np.array(df)
        #print(DataArray)
        #print(df)


        labelencoded=LabelEncoder()

        df['Date']=labelencoded.fit_transform(df['Date']) #label encoding of all categorical columns
        df['Month']=labelencoded.fit_transform(df['Month'])
        df['Day']=labelencoded.fit_transform(df['Day'])
        #print(df)

        instance=0
        for i in df['Volume']: #conversion of units
            valueat=float(df.at[instance, 'Volume'][:-2])
            if(i[-1]=='M'):
                df.at[instance, 'Volume'] = valueat*1000000
            if(i[-1]=='K'):
                df.at[instance, 'Volume'] = valueat*1000
            instance=instance+1

        #print(df)
        df.to_excel('E:\\Sharanya\\MLsem4\\Lab_Session1_Data_op.xlsx', index=False)

        DataArray=np.array(df)
        

        #-------A4---------
        df2=pd.read_excel("E:\\Sharanya\\MLsem4\\Lab_Session1_Data.xlsx", 'IRCTC Stock Price')
        DataArray2=np.array(df2)
        D=DataArray2[:,3]
        print("Mean of Price is=",statistics.mean(D))
        print("Variance of Price is=",statistics.variance(D))

        Days=DataArray2[:,2].reshape(-1, 1)
        Month=DataArray2[:,1]
        PriceWed=[]
        PriceApr=[]
        for i,j in zip(Days,D): #extracting all wednesday price
            #print(i," ---",j)
            if(i=='Wed'):
                PriceWed.append(j)
        #print(PriceWed)
        print("Mean of Price on wednesdays is=",statistics.mean(PriceWed))
        print("Difference between population mean and wednesday mean is=",(statistics.mean(D)-statistics.mean(PriceWed)))
        
        for i,j in zip(Month,D):
            #print(i," ---",j)         
            if(i=='Apr'): #extracting april price
                PriceApr.append(j)
        #print(PriceWed)
        print("Mean of Price during April is=",statistics.mean(PriceApr))
        print("Difference between population mean and April mean is=",(statistics.mean(D)-statistics.mean(PriceApr)))
        
        chg=DataArray[:,-1].reshape(-1, 1)
        losscount=0
        
        for i in chg: #extracting count of loss
            #print(i)
            if(float(i)<0):
                losscount=losscount+1
        
        print("count of loss stock=",losscount)
        print("loss probablity=",losscount/249)

        profitcount=0
        
        for i,k in zip(Days,chg): #extracting count of profit on wednesdays
            #print(i," ---",j)
            if(i=='Wed' and float(k)>0):
                profitcount=profitcount+1

        print("count of profit on Wednesday=",profitcount)
        print("profit on Wednesday probablity=",profitcount/len(PriceWed))

        probab_wed_and_profit=profitcount/len(PriceWed)
        probab_wed=len(PriceWed)/249 #calculation of conditional probablity
        print("conditional probability of making profit given that today is Wednesday=",probab_wed_and_profit/probab_wed)


        print(chg.shape) #scatter plot and conversion into list
        print(Days.shape)
        Days2=DataArray[:,2].reshape(-1, 1)
        chg_listformat=chg.tolist()
        Days_listformat=Days2.tolist()
        plotting.scatter(chg_listformat,Days_listformat)
        plotting.show()

        #------------------------------------------------------------------

        df2=pd.read_excel("E:\\Sharanya\\MLsem4\\Lab_Session1_Data_op.xlsx", 'Sheet1')
        feat_vecs=df2.iloc[:,[0,1,2,4,5,6,7,8]] 
        classlabels=df2.iloc[:,3] #choosing price column

        X_train,X_test,y_train,y_test=train_test_split(feat_vecs,classlabels,test_size=0.3)
    

        scaler=StandardScaler()
        X_train_scaled=scaler.fit_transform(X_train)
        X_test_scaled=scaler.transform(X_test)

        #performing linear regression for prediction 
        LinReg=LinearRegression()
        LinReg.fit(X_train_scaled, y_train)
        
        predict=LinReg.predict(X_test_scaled)
        meansquaredError=mean_squared_error(y_test, predict)
        rootmse=np.sqrt(meansquaredError)
        mape=mean_absolute_percentage_error(y_test, predict)
        r2score=r2_score(y_test, predict)

        print("MSE is=",meansquaredError)
        print("RMSE is=",rootmse)
        print("MAPE is=",mape)
        print("r2 score is=",r2score)

        
    
    irctcstock()

   