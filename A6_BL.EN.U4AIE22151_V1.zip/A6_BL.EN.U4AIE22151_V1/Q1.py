import pandas as pd
import math
import matplotlib.pyplot as plt

    
def activation_func(x):
    if x>=0:
        return 1
    else:
        return 0
    
def bipolarstep(x):
    if x>0:
        return 1
    elif x==0:
        return 0
    else:
        return -1
        
    
def q1():
    w0=10
    w1=0.2
    w2=-0.75
    learn_rate=0.05
    col1=[0,0,1,1]
    col2=[0,1,0,1]
    target_col=[0,0,0,1]
    df=pd.DataFrame({"A":col1,"B":col2,"Z":target_col})
    print(df)
    ep=[]
    er=[]
    for i in range(1,1001):
        ep.append(i)
        sum_squared_error = 0
        for j in range(len(df)):
            x1=df.iloc[j]["A"]
            x2=df.iloc[j]["B"]
            target=df.iloc[j]["Z"]
            yin=w0+x1*w1+x2*w2
            y=activation_func(yin)
            error=target-y
            w0=w0+learn_rate*error
            w1=w1+learn_rate*error*x1
            w2=w2+learn_rate*error*x2
            sum_squared_error+=error**2

        er.append(sum_squared_error)
        if (sum_squared_error < 0.002):
            print("Converged weights:", w0, w1, w2)
            print("Number of epochs needed:", i)
            print("Error values:", er)

            import matplotlib.pyplot as plt
            plt.figure(1)
            plt.xlabel('Epochs')
            plt.ylabel('sum mean squared Error')
            plt.plot(ep, er)
            plt.show()
            break
          

def q1pt2():
    w0=10
    w1=0.2
    w2=-0.75
    learn_rate=0.05
    col1=[0,0,1,1]
    col2=[0,1,0,1]
    target_col=[0,1,1,0]
    df=pd.DataFrame({"A":col1,"B":col2,"Z":target_col})
    print(df)
    ep=[]
    er=[]
    for i in range(1,1001):
        ep.append(i)
        sum_squared_error = 0
        for j in range(len(df)):
            x1=df.iloc[j]["A"]
            x2=df.iloc[j]["B"]
            target=df.iloc[j]["Z"]
            yin=w0+x1*w1+x2*w2
            y=activation_func(yin)
            error=target-y
            w0=w0+learn_rate*error
            w1=w1+learn_rate*error*x1
            w2=w2+learn_rate*error*x2
            sum_squared_error+=error**2

        er.append(sum_squared_error)
        if (sum_squared_error < 0.002):
            print("Converged weights:", w0, w1, w2)
            print("Number of epochs needed:", i)
            print("Error values:", er)

            import matplotlib.pyplot as plt
            plt.figure(2)
            plt.xlabel('Epochs')
            plt.ylabel('sum mean squared Error')
            plt.plot(ep, er)
            plt.show()
            break

def q2():
    w0=10
    w1=0.2
    w2=-0.75
    learn_rate=0.05
    col1=[0,0,1,1]
    col2=[0,1,0,1]
    target_col=[0,0,0,1]
    df=pd.DataFrame({"A":col1,"B":col2,"Z":target_col})
    print(df)
    ep=[]
    er=[]
    for i in range(1,1001):
        ep.append(i)
        sum_squared_error = 0
        for j in range(len(df)):
            x1=df.iloc[j]["A"]
            x2=df.iloc[j]["B"]
            target=df.iloc[j]["Z"]
            yin=w0+x1*w1+x2*w2
            y=bipolarstep(yin)
            error=target-y
            w0=w0+learn_rate*error
            w1=w1+learn_rate*error*x1
            w2=w2+learn_rate*error*x2
            sum_squared_error+=error**2

        er.append(sum_squared_error)
        if (sum_squared_error < 0.002):
            print("Converged weights:", w0, w1, w2)
            print("Number of epochs needed:", i)
            print("Error values:", er)

            import matplotlib.pyplot as plt
            plt.figure(3)
            plt.xlabel('Epochs')
            plt.ylabel('sum mean squared Error')
            plt.plot(ep, er)
            plt.show()
            break
  

q1()
 
q1pt2() 

q2()

