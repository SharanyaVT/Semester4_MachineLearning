import pandas as pd
import numpy as np
import statistics
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_squared_error,mean_absolute_percentage_error,r2_score
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
from sklearn.ensemble import AdaBoostClassifier
from sklearn.datasets import make_classification

class q11:

    def labprojectdataquestions():
        df=pd.read_csv("E:\\Sharanya\\MLsem4\\projectdatasetML.csv",skiprows=86)
        
        
        columnsdrop = ["kepler_name", "koi_comment", "koi_longp", "koi_model_dof", "koi_model_chisq", "koi_sage", "koi_ingress", "kepoi_name", "koi_vet_date", "koi_limbdark_mod", "koi_parm_prov", "koi_tce_delivname", "koi_sparprov", "koi_datalink_dvr", "koi_datalink_dvs", "koi_quarters"]

        
        df.drop(columns=columnsdrop,inplace=True)

        #print(df)

        pd.set_option('display.max_columns', None)
        #print(df.head())

        labelencoded=LabelEncoder()

        df['koi_disposition']=labelencoded.fit_transform(df['koi_disposition']) #label encoding of all categorical columns
        df['koi_vet_stat']=labelencoded.fit_transform(df['koi_vet_stat'])
        df['koi_pdisposition']=labelencoded.fit_transform(df['koi_pdisposition'])
        df['koi_disp_prov']=labelencoded.fit_transform(df['koi_disp_prov'])
        df['koi_fittype']=labelencoded.fit_transform(df['koi_fittype'])
        df['koi_trans_mod']=labelencoded.fit_transform(df['koi_trans_mod'])

        #print(df)

        #for column_name, dtype in df.dtypes.items():
            #print(f"Column '{column_name}' has data type '{dtype}'.")
        #print("------------------------------------") #searching for which coumns have missing values
        null_columns = df.isnull().any()

        for column_name, has_null in null_columns.items():
            if(has_null==True):
                #print(column_name, has_null)
                pass

        #print(null_columns)
        
        for column_name, has_null in null_columns.items():
            if(has_null==True):
                #print(column_name, has_null)
                pass
                instance=0
                for i in df[column_name]:
                    if pd.isnull(i):
                        df.at[instance, column_name] = df[column_name].mean()
                    instance=instance+1
                        
        #print(df)

        #print("--------------------------------------") 

        null_columns = df.isnull().any()
        for column_name, has_null in null_columns.items():
            if(has_null==True):
                #print(column_name, has_null)
                pass

        df.to_csv('E:\\Sharanya\\MLsem4\\correctedfile.csv', index=False)

        feat_vecs=df.iloc[:,:-1]
        classlabels=df.iloc[:,2]

        uniqueclass=np.unique(classlabels)

        #print(feat_vecs)


        instance=0 #replacing missing values with mean
        classmeanlist=[]
        classstdlist=[]
        for i in range(len(feat_vecs)):
            classspecificvector = []
            for j in uniqueclass:
                if classlabels[i] == j:  # 
                    classspecificvector.append(feat_vecs.iloc[i])
        classmean = np.mean(classspecificvector, axis=0)
        classstd =np.std(classspecificvector, axis=0)
        classmeanlist.append(classmean)
        classstdlist.append(classstd)


        #print(classmeanlist)
        #print(classstd)

        for i in classmeanlist:
            for j in classmeanlist:
                print(np.linalg.norm(i - j))

        X_train, X_test, y_train, y_test = train_test_split(feat_vecs, classlabels, test_size=0.4, random_state=42)
        adaboost_Classify=AdaBoostClassifier(n_estimators=50, random_state=42) #descion tree is taken sequentially
        adaboost_Classify.fit(X_train, y_train)
        predicted=adaboost_Classify.predict(X_test)
        accuracy = accuracy_score(y_test, predicted)
        print("Accuracy:", accuracy)
        print(accuracy_score(y_test,predicted))
        from sklearn.metrics import classification_report
        print(classification_report(y_test,predicted))

        from sklearn.model_selection import KFold
        from sklearn.model_selection import cross_val_score
        k=10 #10 splits taken for 9000 row dataset hence 900 rows each fold
        kf=KFold(n_splits=k, shuffle=True, random_state=42)
        kfoldresult=cross_val_score(adaboost_Classify, feat_vecs, classlabels, cv=kf, scoring='accuracy')

        print("cross validation result:",kfoldresult)
        print("Average accuracy:",kfoldresult.mean()) #taking the mean for all results obtained from all iterations

        import shap
        analysis = shap.Explainer(adaboost_Classify.predict, feat_vecs)
        shap_values=analysis.shap_values(feat_vecs)
        #performing shap to plot the contribution of each feature into the classification
        shap.summary_plot(shap_values,feat_vecs)

        
    labprojectdataquestions()
       