import pandas as pd
import math
import matplotlib.pyplot as plt
import numpy as np
    
def activation_func(x):
    if x>=0:
        return 1
    else:
        return 0
    
def bipolarstep(x):
    if x>0:
        return 1
    elif x==0:
        return 0
    else:
        return -1
    
def relU(x):
    if x>0:
        return x
    else:
        return 0
    
def sigmoid(x):
    return 1/(1+np.exp(-x))

def q4():
    w0=10
    w1=0.2
    w2=-0.75
    w3=0.3
    w4=-0.5
    learn_rate=0.05
    col1=[20,16,27,19,24,22,15,18]
    col2=[6,3,6,1,4,1,4,4]
    col3=[2,6,2,2,2,5,2,2]
    col4=[386,289,393,110,280,167,271,274]
    target_col=[1,1,1,0,1,0,1,1]
    convergedlist=[]
    df=pd.DataFrame({"Candies":col1,"Mangoes":col2,"Milk packets":col3,"Payment":col4,"Tx":target_col})
    print(df)
    ep=[]
    er=[]
    
        
    for i in range(1,1001):
        #print("i=",i)
        ep.append(i)
        sum_squared_error = 0
        for j in range(len(df)):
            x1=df.iloc[j]["Candies"]
            x2=df.iloc[j]["Mangoes"]
            x3=df.iloc[j]["Milk packets"]
            x4=df.iloc[j]["Payment"]
            target=df.iloc[j]["Tx"]
            yin=w0+x1*w1+x2*w2+x3*w3+x4*w4
            y=sigmoid(yin)
            error=target-y
            w0=w0+learn_rate*error
            w1=w1+learn_rate*error*x1
            w2=w2+learn_rate*error*x2
            w3=w3+learn_rate*error*x3
            w4=w4+learn_rate*error*x4
            sum_squared_error+=error**2
            #print(sum_squared_error)

        er.append(sum_squared_error)
        if (sum_squared_error < 0.002):
            print("Converged weights:", w0, w1, w2, w3, w4)
            print("Number of epochs needed:", i)
            print("Error values:", er)

            import matplotlib.pyplot as plt
            plt.figure(3)
            plt.xlabel('Epochs')
            plt.ylabel('sum mean squared Error')
            plt.plot(ep, er)
            plt.show()
            break

    if(i==1001):
        print("weights have not converged, error greater than 0.002")
        print("Weights:", w0, w1, w2, w3, w4)
        print("Number of epochs needed:", i)
        print("Error values:", er)
        import matplotlib.pyplot as plt
        plt.figure(3)
        plt.xlabel('Epochs')
        plt.ylabel('sum mean squared Error')
        plt.plot(ep, er)
        plt.show()

    
q4()