import pandas as pd
import math
import matplotlib.pyplot as plt
import numpy as np


def sigmoid(x):
    return 1/(1+np.exp(-x))

def sigmoid_derv(x):
    return x*(1-x)

def q8():
    col1=[0,0,1,1]
    col2=[0,1,0,1]
    target_col1=[1,1,1,0]
    target_col2=[0,0,0,1]
    convergedlist=[]
    df=pd.DataFrame({"A":col1,"B":col2,"Z1":target_col1,"Z2":target_col2})

    input_vec=df.iloc[:,[0,1]]
    output_vec=df.iloc[:,[2,3]]
    
    output_vec = df.iloc[:, -1].values.reshape(-1, 1)

    input_neuron=2
    hidden_neuron=2
    output_neuron=2

    hidden_weights=np.random.uniform(size=(input_neuron,hidden_neuron))
    output_weights=np.random.uniform(size=(hidden_neuron,output_neuron))
    learn_rate=0.05

    for i in range(1,1001):
        hidden_input=np.dot(input_vec,hidden_weights)
        hidden_output=sigmoid(hidden_input)
        output_input=np.dot(hidden_output,output_weights)
        output_output=sigmoid(output_input)
        
        print("Shape of output_vec:", output_vec.shape)
        print("Shape of output_output:", output_output.shape)

        error=output_vec-output_output

        print("error=",error)
        if np.mean(np.abs(error))<=0.02:
            print("epoch", i)
            break

        output_delta=error*sigmoid_derv(output_output)
        output_weights=output_weights+np.dot(hidden_output.T, output_delta)*learn_rate
        hidden_delta=np.dot(output_delta,output_weights.T)*sigmoid_derv(hidden_output)
        hidden_weights=hidden_weights+np.dot(input_vec.T,hidden_delta)*learn_rate

        test=df.iloc[:,[0,1]].values
        hidden_input=np.dot(input_vec,hidden_weights)
        hidden_output=sigmoid(hidden_input)
        output_input=np.dot(hidden_output,output_weights)
        output_output=sigmoid(output_input)

        print("predicted output",output_output)


q8()