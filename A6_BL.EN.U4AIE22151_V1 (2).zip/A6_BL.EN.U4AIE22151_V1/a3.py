import pandas as pd
import math
import matplotlib.pyplot as plt
import numpy as np
    
def activation_func(x):
    if x>=0:
        return 1
    else:
        return 0
    
def bipolarstep(x):
    if x>0:
        return 1
    elif x==0:
        return 0
    else:
        return -1
    
def relU(x):
    if x>0:
        return x
    else:
        return 0
    
def sigmoid(x):
    return 1/(1+np.exp(-x))

def q2():
    w0=10
    w1=0.2
    w2=-0.75
    #learn_rate=0.05
    learn_rate_list = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
    col1=[0,0,1,1]
    col2=[0,1,0,1]
    target_col=[0,0,0,1]
    convergedlist=[]
    df=pd.DataFrame({"A":col1,"B":col2,"Z":target_col})
    print(df)
    ep=[]
    er=[]
    for lr in learn_rate_list:
        learn_rate=lr
        w0=10
        w1=0.2
        w2=-0.75
        for i in range(1,1001):
            #print("i=",i)
            ep.append(i)
            sum_squared_error = 0
            for j in range(len(df)):
                x1=df.iloc[j]["A"]
                x2=df.iloc[j]["B"]
                target=df.iloc[j]["Z"]
                yin=w0+x1*w1+x2*w2
                y=activation_func(yin)
                error=target-y
                w0=w0+learn_rate*error
                w1=w1+learn_rate*error*x1
                w2=w2+learn_rate*error*x2
                sum_squared_error+=error**2
                print(sum_squared_error)

            er.append(sum_squared_error)
            if (sum_squared_error < 0.002):
                convergedlist.append(i)
                break
            print("-----------------------------")


        if(i==1000):
            convergedlist.append(1000)
    
    print(learn_rate_list)
    print(convergedlist)
    import matplotlib.pyplot as plt
    plt.figure(1)
    plt.xlabel('Learning rate')
    plt.ylabel('Epoch')
    plt.plot(learn_rate_list, convergedlist)
    plt.show()

    #---------------------------------------------------

    learn_rate_list = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]
    col1=[0,0,1,1]
    col2=[0,1,0,1]
    target_col=[0,1,1,0]
    convergedlist=[]
    df=pd.DataFrame({"A":col1,"B":col2,"Z":target_col})
    print(df)
    ep=[]
    er=[]
    for lr in learn_rate_list:
        learn_rate=lr
        w0=10
        w1=0.2
        w2=-0.75
        for i in range(1,1001):
            #print("i=",i)
            ep.append(i)
            sum_squared_error = 0
            for j in range(len(df)):
                x1=df.iloc[j]["A"]
                x2=df.iloc[j]["B"]
                target=df.iloc[j]["Z"]
                yin=w0+x1*w1+x2*w2
                y=sigmoid(yin)
                error=target-y
                w0=w0+learn_rate*error
                w1=w1+learn_rate*error*x1
                w2=w2+learn_rate*error*x2
                sum_squared_error+=error**2
                #print(sum_squared_error)

            er.append(sum_squared_error)
            if (sum_squared_error < 0.002):
                convergedlist.append(i)
                break


        if(i==1000):
            convergedlist.append(1000)
    
    print(learn_rate_list)
    print(convergedlist)
    import matplotlib.pyplot as plt
    plt.figure(2)
    plt.xlabel('Epochs')
    plt.ylabel('Learning rate')
    plt.plot(convergedlist, learn_rate_list)
    plt.show()

q2()

