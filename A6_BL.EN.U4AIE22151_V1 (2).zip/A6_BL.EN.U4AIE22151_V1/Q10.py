import pandas as pd
import math
import matplotlib.pyplot as plt
import numpy as np
from sklearn.neural_network import MLPClassifier

def q10():
    col1=[0,0,1,1]
    col2=[0,1,0,1]
    target_col=[0,0,0,1]
    convergedlist=[]
    df=pd.DataFrame({"A":col1,"B":col2,"Z":target_col})

    input_vec=df.iloc[:,[0,1]]
    output_vec=df.iloc[:,-1]

    mlp_classify=MLPClassifier(hidden_layer_sizes=(2,),activation='logistic',max_iter=1000, random_state=42)

    mlp_classify.fit(input_vec,output_vec)
    print("Model trained successfully.")
    try:
        print("And gate")
        print(mlp_classify.predict(input_vec))
    except Exception as e:
        print("An error occurred:", e)
q10()

def q10xor():
    col1=[0,0,1,1]
    col2=[0,1,0,1]
    target_col=[0,1,1,0]
    convergedlist=[]
    df=pd.DataFrame({"A":col1,"B":col2,"Z":target_col})

    input_vec=df.iloc[:,[0,1]]
    output_vec=df.iloc[:,-1]

    mlp_classify=MLPClassifier(hidden_layer_sizes=(2,),activation='logistic',max_iter=1000, random_state=42)

    mlp_classify.fit(input_vec,output_vec)
    print("Model trained successfully.")
    try:
        print("xor gate")
        print(mlp_classify.predict(input_vec))
    except Exception as e:
        print("An error occurred:", e)
q10xor()