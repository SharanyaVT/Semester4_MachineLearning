import pandas as pd
import math
import numpy as np

def euciladean(vector1,vector2,n): #distance calculation
        sum=0
        for i in range(0,n):
            sum=sum+(vector2[i]-vector1[i])**2
        #print(sum)
        return(math.sqrt(sum))

def knnclassifer_sharanya(): #knn implemented
    myframe=pd.read_excel("E:\\Sharanya\\MLsem4\\Lab_Session1_Data.xlsx", sheet_name='Purchase data')
    
    #print(myframe)
    #print(myframe_test)
    
   
    frame_array=np.array(myframe)
    #print(DataArray)
    #print(frame_array)


    #------conversion of date column to label encoded------
    customer_col=frame_array[:,0]
    #print(dates)

    uniquecustomer=np.unique(customer_col) #extracting of unique values of customer column to craete a map for encoding

    dictvalue=0
    from typing import Dict

    customermap1= {}

    for i in uniquecustomer:
        customermap1[i]=dictvalue
        dictvalue=dictvalue+1

    myframe['Customer']=[customermap1[i] for i in myframe['Customer']] #label encoding
    #print(customermap1)
    #print(myframe)

    myframe_test=myframe.iloc[8:,:]
    myframe=myframe.iloc[0:8,:] #train test split

    myframe["target"]=None
    instance=0
    for i in myframe['Payment (Rs)']: #creation of target column
        if(i>200):
            myframe.at[instance, 'target'] = "RICH"
        else:
            myframe.at[instance, 'target'] = "POOR"
        instance=instance+1

    #print(myframe)

    myframe['distance']=0
    testvector=myframe_test.iloc[0,:]
    #print(testvector)
    for i in range(0,8):
        instance_vector = myframe.iloc[i, :5]
        distance_value=euciladean(testvector,instance_vector,5)
        myframe.at[i, 'distance'] = distance_value

    #print(myframe)
    sorted_myframe = myframe.sort_values(by='distance', ascending=True).reset_index(drop=True) #sorting according to least distance first
    #print(sorted_myframe)

    
    k=3
    sum_list=[0,0]
    in_no=0
    sum=0
    targets=["RICH","POOR"]
    for i in targets:
        sum=0
        for j in range(0,k):
            if(i==sorted_myframe.loc[j, 'target']):
                sum=sum+1
        sum_list[in_no]=sum
        in_no=in_no+1

    #print(sum_list)
    max=0 #argmax operation
    for i in range(0,2):
        if(sum_list[i]>=max):
            max=sum_list[i]
            position=i


    #print(position)

    if(position==0): #finding predicted target according to argmax calculation
        predicted_target="RICH"
    else:
        predicted_target="POOR"

    #print(predicted_target)
    return(predicted_target)

     
print(knnclassifer_sharanya())

