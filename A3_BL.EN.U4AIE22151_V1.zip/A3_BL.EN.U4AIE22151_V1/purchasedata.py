import pandas as pd
import numpy as np
import statistics
from sklearn.preprocessing import LabelEncoder
class A1:

    def question1():
        dfpurchase=pd.read_excel("E:\\Sharanya\\MLsem4\\Lab_Session1_Data.xlsx", sheet_name='Purchase data')
        DataArray=np.array(dfpurchase)
        #print(DataArray)
        #print(dfpurchase)



        #print(df)
        dfpurchase.to_excel('E:\\Sharanya\\MLsem4\\Purchase_data_op.xlsx', index=False)

        print(dfpurchase)
        DataArray=np.array(dfpurchase)
        A=DataArray[:,1:-1] #extracts all but last column
        C=DataArray[:,-1].reshape(-1, 1) #extracts last coumn seperately

        print(A.shape)
        print(C.shape)

        A = A.astype('float64')
        rankofA=np.linalg.matrix_rank(A)
        print("Rank of A is ",rankofA)
        Ainverse=np.linalg.pinv(A) #finds pseudo inverse since not a square matrix
        print(Ainverse)

        X=Ainverse @ C
        print(X)

    question1()



    


